package com.example.prognoza_zelnik;

import com.google.gson.annotations.SerializedName;

public class WeatherMainInfo {
    @SerializedName("temp")
    private double temperature;

    public double getTemperature() {
        return temperature;
    }
}