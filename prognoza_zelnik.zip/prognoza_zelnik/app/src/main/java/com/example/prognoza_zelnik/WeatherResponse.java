package com.example.prognoza_zelnik;

import com.google.gson.annotations.SerializedName;

public class WeatherResponse {
    @SerializedName("main")
    private WeatherMainInfo mainInfo;

    public WeatherMainInfo getMainInfo() {
        return mainInfo;
    }
}



