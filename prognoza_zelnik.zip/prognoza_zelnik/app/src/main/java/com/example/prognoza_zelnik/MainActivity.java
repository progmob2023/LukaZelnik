package com.example.prognoza_zelnik;


import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class MainActivity extends AppCompatActivity {

    private AutoCompleteTextView cityAutoCompleteTextView;
    private Button refreshButton;
    private TextView temperatureTextView;
    private WeatherApiService weatherApiService;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        cityAutoCompleteTextView = findViewById(R.id.cityAutoCompleteTextView);
        refreshButton = findViewById(R.id.refreshButton);
        temperatureTextView = findViewById(R.id.temperatureTextView);

        // Inicijalizacija Retrofit
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl("https://api.openweathermap.org/data/2.5/")
                .addConverterFactory(GsonConverterFactory.create())
                .build();

        weatherApiService = retrofit.create(WeatherApiService.class);

        // Postavljanje adaptera za AutoCompleteTextView
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_dropdown_item_1line, getCitySuggestions());
        cityAutoCompleteTextView.setAdapter(adapter);

        // Postavljanje slušatelja na gumb za osvježavanje
        refreshButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Izvođenje Retrofit zahtjeva s gradom koji je korisnik unio
                String selectedCity = cityAutoCompleteTextView.getText().toString();
                new WeatherTask().execute(selectedCity);
            }
        });
    }

    private class WeatherTask extends AsyncTask<String, Void, Void> {
        @Override
        protected Void doInBackground(String... params) {
            // Dohvati API ključ
            String apiKey = "8649b9d1a3d0e338d94a97589a0208f9";

            // Izvođenje Retrofit zahtjeva
            Call<WeatherResponse> call = weatherApiService.getWeather(params[0], apiKey);

            call.enqueue(new Callback<WeatherResponse>() {
                @Override

                public void onResponse(Call<WeatherResponse> call, Response<WeatherResponse> response) {
                    // Obrada uspješnog odgovora
                    if (response.isSuccessful()) {
                        WeatherResponse weatherResponse = response.body();
                        // Dohvati stvarnu vrijednost temperature iz odgovora
                        WeatherMainInfo mainInfo = weatherResponse.getMainInfo();
                        double temperatureInKelvin = mainInfo.getTemperature();

                        double temperatureInCelsius = temperatureInKelvin - 273.15;

                        // Zaokruži temperaturu na najbliži cijeli broj
                        long roundedTemperature = Math.round(temperatureInCelsius);

                        // Postavi vrijednost temperature u TextView
                        temperatureTextView.setText("Temperature: " + roundedTemperature + " °C");
                    } else {
                        // Obrada neuspješnog odgovora
                    }
                }


                @Override
                public void onFailure(Call<WeatherResponse> call, Throwable t) {
                    // Obrada greške tijekom izvođenja zahtjeva
                }
            });

            return null;
        }
    }

    // Metoda koja vraća popis gradova (primjer)
    private List<String> getCitySuggestions() {
        List<String> cities = new ArrayList<>();
        cities.add("City1");
        cities.add("City2");
        cities.add("City3");
        // Dodajte stvarne gradove iz vaše aplikacije ili koristite neki API za prijedloge gradova
        return cities;
    }
}
